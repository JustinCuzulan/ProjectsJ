<!DOCTYPE html>
<html>
    <head>
        <style>
            #footer{
                
                position: absolute;
                bottom: -110px;
                right:30px;
                background-color: rgb(42, 15, 8);
                border-bottom-right-radius: 30px;
    
    height: 70px;
    width: 300px;
    text-align: right;
    padding: 5px;
            }
        </style>
    </head>
    <body>
    
<footer>
    <div id="footer"><p style="color: rgb(212,113,54);">Justin Cuzulan 3995®</p></div>
</footer>



    
</body>

</html>